# Claim registry

The machine-readable authority is `claim_registry.json`. The headline scope is h22 only; strong real-event no-hair and mode-general claims are not ready.

| ID | Registry status | Classification |
|---|---|---|
| `h22_model_order_mechanism` | `SUPPORTING` | core positive mechanism |
| `h22_blind40_prediction` | `PASS` | core positive preexisting blind |
| `h22_false_kerr_suppression` | `PASS` | core positive colored noise |
| `h22_cross_extraction_robustness` | `PASS` | core positive extraction systematics |
| `gw150914_fixed_sky_feasibility` | `SUPPORTING` | event supporting not strong no hair |
| `h33_cross_extraction` | `PRESERVED_FAIL` | negative mode generalization |
| `gw150914_joint_sky_v1` | `INVALID` | excluded invalid history |
| `gw150914_joint_sky_v2` | `FAIL` | preserved strict failure |
| `gw150914_joint_sky_v3_k64` | `SUPPORTING` | retrospective numerical extension |
| `gw250114_original_prospective_test` | `INVALID` | invalid performance test due to protocol timing |
| `h6_v3_terminal_sampler_failure` | `TERMINAL_PROTOCOL_FAIL` | protocol failure not scientific performance |
| `blind40_standard_remnant_sensitivity` | `POST_HOC_NONCOVERING` | supporting robustness only |
| `detector16_standard_remnant_sensitivity` | `POST_HOC_NONCOVERING` | supporting robustness only |

The blind40 and detector16 standard-remnant entries are explicitly post-hoc and noncovering. Their result/receipt pairs support only the stated robustness interpretation.
