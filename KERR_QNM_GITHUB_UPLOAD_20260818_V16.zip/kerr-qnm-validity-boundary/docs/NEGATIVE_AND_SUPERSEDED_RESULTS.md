# Negative and superseded results

The public claim registry retains negative evidence rather than deleting or relabeling it. Required statuses are `PRESERVED_FAIL` for h33, `INVALID` and `FAIL` for GW150914 V1 and V2, `SUPPORTING` retrospective K64 for V3, `INVALID` for the GW250114 prospective performance test, and `TERMINAL_PROTOCOL_FAIL` for H6v3 sampler nonconvergence.

The terminology V6 receipt is also retained as a FAIL. V7 supersedes it only because three frozen-source checks in V6 contained documented auditor-only stale/regex errors; V7 binds the same freeze manifest and every one of its inputs and embeds the exact V6 receipt identity.
