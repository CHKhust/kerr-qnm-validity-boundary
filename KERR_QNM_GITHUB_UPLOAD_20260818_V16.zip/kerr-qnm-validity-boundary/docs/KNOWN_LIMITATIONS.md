# Known limitations

- The validated headline is h22-only; the h33 cross-extraction gate is a preserved 42/48 failure.
- GW150914 fixed-sky results are feasibility evidence. V1 is invalid, V2 fails its strict common-sample threshold, and V3 K64 is retrospective supporting evidence only.
- The original GW250114 prospective run is an invalid performance test because its timing reference placed the analysis windows before the official peak. Corrected results are retrospective diagnostics only.
- H6v3 terminated at the frozen sampler-nonconvergence condition. Scientific performance is unavailable.
- Both standard-remnant sensitivities are post-hoc and noncovering; neither is a new blind validation.
