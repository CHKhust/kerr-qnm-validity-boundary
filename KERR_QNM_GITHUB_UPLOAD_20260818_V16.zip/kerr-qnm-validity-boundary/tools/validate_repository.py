#!/usr/bin/env python3
"""Validate the V9 public repository without network access."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CHECKSUM = "manifests/repository_checksums.sha256"
SHA_RE = re.compile(r"[0-9a-f]{64}\Z")
WIN_ABS = re.compile(r"(?<![A-Za-z0-9_])[A-Za-z]:[\\/][^\s\"'<>]+")
LOCAL_ABS = re.compile(r"(?<![A-Za-z0-9:])/(?:home|opt)/[^\s\"'<>]+")
RAW = {".npy", ".npz", ".h5", ".hdf5", ".hdf", ".pkl", ".pickle", ".pt", ".pth", ".bin", ".dat", ".raw", ".zarr"}
VM = {".qcow", ".qcow2", ".vdi", ".vhd", ".vhdx", ".vmdk", ".iso", ".ova", ".ovf", ".img"}
KEYS = {".pem", ".key", ".p12", ".pfx", ".jks", ".keystore", ".der", ".crt"}
ARCHIVES = {".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz", ".7z", ".whl"}
FORBIDDEN_NAMES = {"id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", ".env", ".env.local", ".env.production", "known_hosts"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(relative: str):
    with (ROOT / relative).open(encoding="utf-8") as stream:
        return json.load(stream)


def fail(message: str) -> None:
    raise RuntimeError(message)


def file_set() -> set[str]:
    return {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file() and ".git" not in path.relative_to(ROOT).parts
    }


def validate_whitelist() -> None:
    manifest = load("manifests/release_whitelist.json")
    if manifest.get("schema_version") != "EXPLICIT_RELEASE_WHITELIST_V9_1":
        fail("unexpected release-whitelist schema")
    allowed = manifest.get("allowed_paths")
    if not isinstance(allowed, list) or len(allowed) != len(set(allowed)):
        fail("allowed_paths must be a unique list")
    actual = file_set()
    expected = set(allowed)
    if actual != expected:
        fail(f"repository differs from explicit whitelist: missing={sorted(expected-actual)}, extra={sorted(actual-expected)}")
    if any("build_curated_snapshot" in value for value in expected):
        fail("legacy snapshot builder was staged")


def validate_checksums() -> None:
    path = ROOT / CHECKSUM
    records: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line:
            continue
        try:
            digest, relative = line.split("  ", 1)
        except ValueError as exc:
            raise RuntimeError("malformed repository checksum line") from exc
        if SHA_RE.fullmatch(digest) is None or relative in records:
            fail("invalid or duplicate repository checksum entry")
        records[relative] = digest
    expected_paths = file_set() - {CHECKSUM}
    if set(records) != expected_paths:
        fail("repository checksum coverage is not exact")
    for relative, expected in records.items():
        if sha256(ROOT / relative) != expected:
            fail(f"repository checksum mismatch: {relative}")


def validate_security() -> None:
    private_markers = ["BEGIN " + "PRIVATE KEY", "BEGIN " + "RSA PRIVATE KEY", "BEGIN " + "OPENSSH PRIVATE KEY"]
    errors: list[str] = []
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT).as_posix()
        if ".git" in path.relative_to(ROOT).parts:
            continue
        if path.is_symlink():
            errors.append(f"symlink:{relative}")
            continue
        if not path.is_file():
            continue
        suffix = path.suffix.lower()
        parts_lower = {part.lower() for part in path.relative_to(ROOT).parts}
        if "__pycache__" in parts_lower or suffix in {".pyc", ".pyo"}:
            errors.append(f"bytecode:{relative}")
        if suffix == ".log":
            errors.append(f"log:{relative}")
        if suffix in RAW:
            errors.append(f"raw-array:{relative}")
        if suffix in VM:
            errors.append(f"vm-image:{relative}")
        if suffix in KEYS or path.name.lower() in FORBIDDEN_NAMES:
            errors.append(f"key-or-env:{relative}")
        if suffix in ARCHIVES:
            errors.append(f"nested-archive:{relative}")
        if path.stat().st_size <= 8 * 1024 * 1024:
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if WIN_ABS.search(text):
                errors.append(f"windows-absolute-path:{relative}")
            if LOCAL_ABS.search(text):
                errors.append(f"local-posix-path:{relative}")
            if any(marker in text for marker in private_markers):
                errors.append(f"private-key-marker:{relative}")
    if errors:
        fail("security policy violations: " + ", ".join(errors))


def validate_metadata() -> None:
    citation = (ROOT / "CITATION.cff").read_text(encoding="utf-8")
    required = [
        "cff-version: 1.2.0",
        "title: 'Predicting the Validity Boundary of Finite Quasinormal Mode Spectroscopy'",
        "family-names: 'Chen'",
        "family-names: 'Wang'",
        "family-names: 'Shao'",
        "email: 'ppwang@cqu.edu.cn'",
        "license: BSD-3-Clause",
        "date-released: 2026-08-17",
    ]
    if any(marker not in citation for marker in required):
        fail("CITATION.cff lacks required current metadata")
    lowered = citation.lower()
    if "placeholder" in lowered or "repository-code:" in lowered or "example.com" in lowered:
        fail("CITATION.cff contains a placeholder or repository URL field")
    license_text = (ROOT / "LICENSE").read_text(encoding="utf-8")
    if "BSD 3-Clause License" not in license_text or "Redistribution and use" not in license_text:
        fail("LICENSE is not BSD-3-Clause text")


def validate_claims() -> None:
    registry = load("results/claim_registry.json")
    if registry.get("strong_real_event_no_hair_claim_ready") is not False:
        fail("strong real-event no-hair claim flag changed")
    if registry.get("mode_general_claim_ready") is not False:
        fail("mode-general claim flag changed")
    entries = {item.get("id"): item for item in registry.get("entries", []) if isinstance(item, dict)}
    expected = {
        "h33_cross_extraction": "PRESERVED_FAIL",
        "gw150914_joint_sky_v1": "INVALID",
        "gw150914_joint_sky_v2": "FAIL",
        "gw150914_joint_sky_v3_k64": "SUPPORTING",
        "gw250114_original_prospective_test": "INVALID",
        "h6_v3_terminal_sampler_failure": "TERMINAL_PROTOCOL_FAIL",
        "blind40_standard_remnant_sensitivity": "POST_HOC_NONCOVERING",
        "detector16_standard_remnant_sensitivity": "POST_HOC_NONCOVERING",
    }
    for identifier, status in expected.items():
        if entries.get(identifier, {}).get("status") != status:
            fail(f"claim status changed: {identifier}")
    h33 = entries["h33_cross_extraction"]
    if h33.get("metrics") != {"fraction": 0.875, "gate_fraction": 0.9, "passed": 42, "total": 48}:
        fail("h33 42/48 preserved-failure metrics changed")
    v3 = entries["gw150914_joint_sky_v3_k64"]
    if v3.get("retrospective") is not True or v3.get("quadrature_nodes") != 64:
        fail("GW150914 V3 K64 scope changed")
    gw250 = entries["gw250114_original_prospective_test"]
    if gw250.get("prospective_evidence") is not False or gw250.get("corrected_analysis_retrospective_only") is not True:
        fail("GW250114 invalid/prospective lineage changed")
    h6 = entries["h6_v3_terminal_sampler_failure"]
    if h6.get("failure_trigger") != "SAMPLER_NONCONVERGENCE" or h6.get("scientific_performance_verdict") != "UNAVAILABLE":
        fail("H6v3 sampler-failure scope changed")
    for identifier in ("blind40_standard_remnant_sensitivity", "detector16_standard_remnant_sensitivity"):
        item = entries[identifier]
        if item.get("new_blind_validation") is not False or item.get("principal_plot_input") is not False:
            fail(f"post-hoc sensitivity was promoted: {identifier}")
    for item in entries.values():
        for record in item.get("evidence", []):
            relative = record.get("path")
            if not isinstance(relative, str) or not (ROOT / relative).is_file():
                fail("claim evidence path is missing")
            if record.get("sha256") != sha256(ROOT / relative):
                fail(f"claim evidence hash changed: {relative}")


def validate_plot_inputs() -> None:
    expected = {
        "model_order_kerr_clock_result.json",
        "overtone_clearance_clock_result.json",
        "scalar_vector_empirical_head_to_head_result.json",
        "gw150914_lalsuite_coherent_boundary_pushforward_result.json",
        "gw150914_real_event_final_gate_result.json",
        "v3_predicted_K64.json",
        "v3_conservative_K64.json",
        "gw250114_root_cause_and_scientific_increment_v1.json",
    }
    directory = ROOT / "manuscript" / "figure_data"
    actual = {path.name for path in directory.iterdir() if path.is_file()}
    if actual != expected:
        fail("figure_data is not the exact compact plotting-input set")
    source = (ROOT / "manuscript" / "plot_prl_figures.py").read_text(encoding="utf-8")
    if "WORKSPACE" in source or "QNM_FIGURE_DATA" in source or 'load("work/' in source or "HERE.parents" in source:
        fail("plotting script contains a workspace fallback")
    if 'FIGURE_DATA = HERE / "figure_data"' not in source:
        fail("plotting inputs are not repository-relative")


def validate_external_manifest() -> None:
    manifest = load("manifests/external_data.json")
    entries = manifest.get("entries")
    if not isinstance(entries, list) or len(entries) != 5 or len(entries) == 694:
        fail("external-data manifest is not the compact five-record manifest")
    sxs = entries[0]
    if sxs.get("doi") != "10.5281/zenodo.15415231" or len(sxs.get("logical_ids", [])) != 40:
        fail("SXS external identity changed")
    for item in entries:
        urls = [value for key, value in item.items() if key.endswith("url")]
        if not urls or any(not isinstance(value, str) or not value.startswith("https://") for value in urls):
            fail("external record lacks an official HTTPS URL")
        if item.get("redistributed") is not False:
            fail("external raw data must not be redistributed")


def validate_audits() -> None:
    evidence = load("manuscript/audits/FINAL_SUBMISSION_EVIDENCE_AUDIT_V12.json")
    v6 = load("manuscript/audits/FINAL_TEXT_TERMINOLOGY_AUDIT_V6_PRESERVED_FAIL.json")
    v7 = load("manuscript/audits/FINAL_TEXT_TERMINOLOGY_AUDIT_V7.json")
    pdf = load("manuscript/audits/FINAL_PDF_QA.json")
    freeze = load("manuscript/audits/FINAL_AUDIT_HASH_MANIFEST_V12_V6.json")
    live = load("manuscript/audits/REFERENCE_METADATA_AUDIT_V2_LIVE_FAIL.json")
    cache = load("manuscript/audits/REFERENCE_METADATA_AUDIT_V2_CACHE_FALLBACK.json")
    whitelist = load("manifests/release_whitelist.json")
    sources = {item.get("destination"): item for item in whitelist.get("source_files", [])}
    if evidence.get("status") != "FINAL_SUBMISSION_EVIDENCE_AUDIT_V12_PASS" or evidence.get("all_checks_pass") is not True:
        fail("V12 evidence audit is not PASS")
    if v6.get("status") != "FINAL_TEXT_TERMINOLOGY_AUDIT_V6_FAIL" or v6.get("all_checks_pass") is not False:
        fail("V6 auditor-bug FAIL was not preserved")
    if v7.get("status") != "FINAL_TEXT_TERMINOLOGY_AUDIT_V7_PASS" or v7.get("all_checks_pass") is not True or v7.get("supersedes_due_to_auditor_bug") != "V6":
        fail("V7 terminology audit is not the narrow auditor-bug correction PASS")
    v6_source = sources.get("manuscript/audits/FINAL_TEXT_TERMINOLOGY_AUDIT_V6_PRESERVED_FAIL.json", {})
    if v7.get("preserved_v6_receipt", {}).get("sha256") != v6_source.get("source_sha256"):
        fail("V7 does not bind the original preserved V6 receipt")
    pdf_status = pdf.get("status")
    if pdf.get("all_checks_pass") is not True or not isinstance(pdf_status, str) or not pdf_status.startswith("FINAL_PDF_QA_") or not pdf_status.endswith("_PASS"):
        fail("final PDF QA is not PASS")
    if freeze.get("schema_version") != "FINAL_AUDIT_HASH_MANIFEST_V12_V6_1" or len(freeze.get("hashes", {})) < 1:
        fail("populated freeze manifest is missing or invalid")
    if live.get("status") != "REFERENCE_METADATA_AUDIT_V2_FAIL" or live.get("network_failure_count") != 46:
        fail("live metadata network gap was not preserved")
    if cache.get("status") != "REFERENCE_METADATA_AUDIT_V2_AUTHORITATIVE_CACHE_PASS" or cache.get("machine_pass_count") != 47:
        fail("authoritative-cache metadata PASS is missing")
    cache_source = sources.get("manuscript/audits/REFERENCE_METADATA_AUDIT_V1.json", {})
    if cache.get("source_cache", {}).get("sha256") != cache_source.get("source_sha256") or cache.get("source_cache", {}).get("bytes") != cache_source.get("source_bytes"):
        fail("authoritative-cache fallback is not bound to the original V1 cache")


def main() -> int:
    validate_whitelist()
    validate_checksums()
    validate_security()
    validate_metadata()
    validate_claims()
    validate_plot_inputs()
    validate_external_manifest()
    validate_audits()
    print(json.dumps({"status": "KERR_QNM_PUBLIC_REPOSITORY_V9_PASS", "files": len(file_set())}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
