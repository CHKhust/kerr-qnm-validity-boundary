# Notice

This repository combines author-written software and research receipts with citations to external SXS and GWOSC data. External data are not redistributed and remain subject to their providers' terms and citation requirements. Scientific result JSON is provided as provenance; the BSD-3-Clause license applies to the software and repository-authored documentation, not to third-party data.
