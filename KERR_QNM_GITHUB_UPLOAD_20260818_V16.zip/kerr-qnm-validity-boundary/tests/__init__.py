"""Public repository tests."""
