Dear Editors,

Please consider our manuscript, "Predicting the Validity Boundary of Finite Quasinormal Mode Spectroscopy," for publication in Physical Review Letters.

We present the source-informed QNM validity boundary (SQVB), which estimates when a finite quasinormal-mode model becomes adequate for spectral inference before the target ringdown is analyzed. A finite mode sum may fit the waveform well while biasing the inferred QNM frequency and damping rate. SQVB predicts omitted QNM excitation from binary parameters, fixes the Kerr decay rates with an independent remnant estimate, and compares the projected truncation bias with the local statistical error.

We tested SQVB without using the target waveform to set the analysis. For the two-mode 220+221 basis at ringdown signal-to-noise ratio (SNR) 100, the median absolute error in 40 blinded numerical-relativity waveforms is zero and 34 predictions are within 2M. A post hoc sensitivity audit replacing catalog remnants with standard remnant fits leaves all 40 blind predictions and all 32 detector start-and-basis decisions unchanged. With the Advanced LIGO design noise spectrum, the SQVB start-time and basis rule reduces false local-Gaussian Kerr exclusions from 94.1 to 3.4 percent at 70 solar masses and from 99.4 to 4.7 percent at 140 solar masses. It retains more than four times the median selected-window SNR of a uniform late comparator. Across 20 paired boundary evaluations from ten evolutions at two masses, two extraction methods change the boundary by at most 1M.

The result answers a direct question in black-hole spectroscopy. How early can a finite-mode model be used without appreciable finite-basis bias in a Kerr or no-hair test? Waveform agreement and accurate spectral inference are different conditions. SQVB estimates the second condition before the target ringdown result is examined. This gives a direct analysis rule for future high-SNR events.

The main result applies to the dominant mode of aligned-spin binaries. The h33 stress test does not pass its fixed criterion, so we make no claim for other modes. For GW150914, SQVB selects a start near 11M. A retrospective likelihood-level check integrates the time, sky-position, and polarization marginal of the low-frequency posterior on detector samples common to every node. The 11M and 15M results both contain Kerr and differ by 0.081 and 0.057 pooled standard deviations in frequency and damping. This check discards part of the active window, does not restore prospective ordering, and is not part of the principal validation.

This manuscript reports original work that has not been published previously and is not under consideration for publication elsewhere. All authors have read and approved the manuscript and agree to its submission to Physical Review Letters. The manuscript has not previously been considered by an APS journal and is not part of a joint submission. The authors declare no conflicts of interest.

Sincerely,

Pan-Pan Wang

Corresponding author

College of Physics, Chongqing University

ppwang@cqu.edu.cn
