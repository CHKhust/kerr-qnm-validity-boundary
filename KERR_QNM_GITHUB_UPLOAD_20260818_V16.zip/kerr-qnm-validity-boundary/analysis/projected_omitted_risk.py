"""Detector-weighted vector projection of omitted ringdown content.

The construction is the profiled linear-signal bias formula.  Complex
amplitudes of included modes are nuisance parameters.  Their column space is
removed before omitted content is projected onto the target QNM frequency and
damping derivatives.  Multiple omissions are summed coherently before the
projection, retaining their phases and interference.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable

import numpy as np


PSD = Callable[[np.ndarray], np.ndarray]


def flat_psd(frequencies: np.ndarray) -> np.ndarray:
    return np.ones_like(np.asarray(frequencies, dtype=float))


def aligo_zero_det_high_power_psd(frequencies: np.ndarray) -> np.ndarray:
    f = np.asarray(frequencies, dtype=float)
    psd = np.full_like(f, np.inf)
    valid = (f >= 20.0) & (f <= 1024.0)
    x = f[valid] / 215.0
    value = 1.0e-49 * (
        x ** (-4.14)
        - 5.0 * x ** (-2.0)
        + 111.0 * (1.0 - x * x + 0.5 * x**4) / (1.0 + 0.5 * x * x)
    )
    psd[valid] = np.maximum(value, 1.0e-52)
    return psd


def end_taper(size: int) -> np.ndarray:
    window = np.ones(size, dtype=float)
    tail = max(4, int(round(0.1 * size)))
    phase = np.linspace(0.0, np.pi, tail)
    window[-tail:] = 0.5 * (1.0 + np.cos(phase))
    return window


def detector_features(series: np.ndarray, dt_s: float, psd: PSD) -> np.ndarray:
    """Map a complex multipole to a real whitened feature vector."""
    series = np.asarray(series, dtype=np.complex128)
    nfft = 1
    while nfft < 8 * series.size:
        nfft *= 2
    frequencies = np.fft.rfftfreq(nfft, d=dt_s)
    values = psd(frequencies)
    valid = np.isfinite(values) & (values > 0.0)
    if not np.any(valid):
        raise ValueError("PSD has no finite positive support")
    weight = np.sqrt(4.0 * dt_s / np.maximum(values[valid], 1.0e-300))
    taper = end_taper(series.size)
    blocks: list[np.ndarray] = []
    for quadrature in (series.real, series.imag):
        spectrum = np.fft.rfft(quadrature * taper, n=nfft)[valid]
        blocks.extend((weight * spectrum.real, weight * spectrum.imag))
    return np.concatenate(blocks)


def coefficient_features(basis: np.ndarray, dt_s: float, psd: PSD) -> tuple[np.ndarray, np.ndarray]:
    return detector_features(basis, dt_s, psd), detector_features(1j * basis, dt_s, psd)


def combine(columns: tuple[np.ndarray, np.ndarray], coefficient: complex) -> np.ndarray:
    return coefficient.real * columns[0] + coefficient.imag * columns[1]


def projection_risk(
    time_M: np.ndarray,
    included: Iterable[tuple[complex, complex]],
    omitted: Iterable[tuple[complex, complex]],
    *,
    target_omega: complex,
    target_coefficient: complex,
    dt_s: float,
    rho: float,
    psd: PSD = aligo_zero_det_high_power_psd,
) -> dict:
    """Return profiled bias and significance for simultaneous omissions.

    Frequencies use the convention omega = omega_re - i*gamma.  Each mode is
    represented by (omega, complex coefficient) and exp(-i*omega*t).
    """
    time_M = np.asarray(time_M, dtype=float)
    included = tuple(included)
    omitted = tuple(omitted)
    if not included:
        raise ValueError("at least one included mode is required")

    included_columns: list[np.ndarray] = []
    full_reference = np.zeros(0, dtype=float)
    for index, (omega, coefficient) in enumerate(included):
        basis = np.exp(-1j * omega * time_M)
        columns = coefficient_features(basis, dt_s, psd)
        included_columns.extend(columns)
        contribution = combine(columns, coefficient)
        if index == 0:
            full_reference = np.zeros_like(contribution)
        full_reference += contribution

    omitted_vector = np.zeros_like(full_reference)
    scalar_omitted_norm_sum = 0.0
    for omega, coefficient in omitted:
        basis = np.exp(-1j * omega * time_M)
        contribution = combine(coefficient_features(basis, dt_s, psd), coefficient)
        omitted_vector += contribution
        scalar_omitted_norm_sum += float(np.linalg.norm(contribution))
        full_reference += contribution

    amplitude_matrix = np.column_stack(included_columns)
    q, _ = np.linalg.qr(amplitude_matrix, mode="reduced")

    def complement(vector: np.ndarray) -> np.ndarray:
        return vector - q @ (q.T @ vector)

    target_basis = np.exp(-1j * target_omega * time_M)
    derivative_re = combine(
        coefficient_features(-1j * time_M * target_basis, dt_s, psd),
        target_coefficient,
    )
    derivative_gamma = combine(
        coefficient_features(-time_M * target_basis, dt_s, psd),
        target_coefficient,
    )
    jacobian = np.column_stack((complement(derivative_re), complement(derivative_gamma)))
    projected_omission = complement(omitted_vector)
    delta = np.linalg.lstsq(jacobian, projected_omission, rcond=None)[0]

    reference_norm = max(float(np.linalg.norm(full_reference)), 1.0e-30)
    scale = float(rho / reference_norm)
    information = (scale * jacobian).T @ (scale * jacobian)
    covariance = np.linalg.pinv(information)
    significance = float(np.sqrt(max(float(delta @ information @ delta), 0.0)))
    fractional_weight = np.diag(
        (1.0 / target_omega.real**2, 1.0 / abs(target_omega.imag) ** 2)
    )
    mean_squared_fractional_error = float(
        delta @ fractional_weight @ delta + np.trace(fractional_weight @ covariance)
    )
    coherent_norm = float(np.linalg.norm(omitted_vector))
    return {
        "delta_omega_re": float(delta[0]),
        "delta_gamma": float(delta[1]),
        "fractional_delta_omega_re": float(delta[0] / target_omega.real),
        "fractional_delta_gamma": float(delta[1] / abs(target_omega.imag)),
        "B": significance,
        "mean_squared_fractional_error": mean_squared_fractional_error,
        "coherent_omitted_norm": coherent_norm,
        "scalar_omitted_norm_sum": scalar_omitted_norm_sum,
        "interference_ratio": float(coherent_norm / max(scalar_omitted_norm_sum, 1.0e-30)),
        "fisher_condition_number": float(np.linalg.cond(information)),
        "included_mode_count": len(included),
        "omitted_mode_count": len(omitted),
    }
