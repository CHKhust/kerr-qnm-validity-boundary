# Reproducibility boundary

The repository is self-contained for validation, unit tests, figure regeneration, and manuscript compilation. Figure generation reads only eight compact JSON inputs under `manuscript/figure_data`. Scientific recomputation from raw SXS or GWOSC arrays is outside this public package; official upstream identities are recorded in `manifests/external_data.json`.

At release time the builder initializes a fresh Git repository, commits only checksum-listed files, clones it without hard links, runs the validator and unit tests, regenerates all five figures, and compiles the main text, supplement, and cover letter with `latexmk`.
