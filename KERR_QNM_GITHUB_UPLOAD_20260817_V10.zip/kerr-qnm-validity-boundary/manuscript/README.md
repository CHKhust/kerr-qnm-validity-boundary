# Frozen manuscript bundle

This directory contains the frozen TeX, compiled PDFs, bibliography output, five figure PDFs, plotting program, compact repository-relative figure inputs, and final audits. The four main figures are freeze-bound; the supplemental GW250114 figure is retrospective diagnostic material.

`FINAL_TEXT_TERMINOLOGY_AUDIT_V6_PRESERVED_FAIL.json` is retained for transparency. `FINAL_TEXT_TERMINOLOGY_AUDIT_V7.json` is the passing nonoverwriting correction limited to documented auditor bugs.
