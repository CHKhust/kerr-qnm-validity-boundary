# GW250114 root-cause conclusion (2026-08-12)

## Outcome

The original execution result remains exactly
`GW250114_PROSPECTIVE_REAL_EVENT_GATES_FAIL`, but it is **not a valid
performance test** of the spectroscopy rule.  Its physical interpretation is
`NOT_EVALUABLE_IMPLEMENTATION_TIMING_ERROR`.

The contract treated the GWOSC catalog timestamp `1420878141.2`, rounded to
0.1 s, as an exact strain peak.  The official NRSur7dq4 maximum-likelihood
rotation-invariant strain-norm peak is `1420878141.235932`.  The 35.932 ms
error is 99.88 units of the detector total mass used by the contract, placing
the intended 5M, 11M, and 15M analyses at approximately -94.9M, -88.9M, and
-84.9M relative to the actual peak.

The low-frequency Bilby likelihood had analytically marginalized time and
phase.  Its exported CSV retained the segment-start DeltaFunction time; the
analysis failed to reconstruct the marginalized time posterior before binding
the ringdown contract.  It also combined separate marginal medians for sky
parameters instead of selecting or marginalizing a physical joint state.

## Non-overwriting diagnosis

With the official peak and matching reference sky, while preserving the
original PSD, calibration, remnant prior, QNM bases, relative 5M/11M/15M
delays, and no-hair priors:

| analysis | network SNR | median delta-f | median delta-gamma | Kerr in joint 95% |
|---|---:|---:|---:|:---:|
| 5M, R2A0 | 29.82 | 0.020 | 0.006 | yes |
| 11M, R3A1 | 19.34 | 0.048 | -0.009 | yes |
| 15M, R3A1 | 14.25 | 0.050 | 0.084 | yes |

All three nominal chains converged.  All four predicted/conservative
calibration-envelope stress trials also converged and contained Kerr.

Causal isolation supports the same conclusion:

- correct peak with the original sky: SNR 27.59 and Kerr contained;
- correct sky with the erroneous rounded peak: SNR 6.40 and Kerr excluded in
  the short diagnostic chain (which itself did not converge sufficiently).

Thus the absolute peak error is the primary cause.  The incoherent sky tuple
is secondary (about 5--6M in detector arrival time).  Independent audits rule
out the scientific runner's LAL time projection, polyphase downsampling group
delay, sub-sample grid quantization, calibration stress, and a hidden
IMRPhenomXAS coalescence-to-amplitude-peak offset as primary causes.

## Low-frequency-only feasibility

A real joint sample selected from the time-reconstructed 20--100 Hz posterior,
without target ringdown input, yields for the predicted 11M/R3A1 analysis:

- network SNR 17.63;
- median `(delta-f, delta-gamma) = (0.044, 0.043)`;
- both marginal 95% intervals and the legacy joint 95% region contain Kerr;
- R-hat 1.00, minimum bulk ESS 4465, zero divergences.

Across 64 joint samples from the 20--100 and 20--132 Hz posteriors,
IMRPhenomXAS places its polarization-amplitude peak within 0.5 ns of its
`geocent_time` convention.  The 20--132 Hz inferred detector peaks differ
from the official reference by only 0.095 ms (H1) and 0.308 ms (L1).

This establishes a viable future low-frequency-only timing construction, but
the selection rule was written after target access.  It therefore diagnoses
feasibility and cannot retroactively turn GW250114 into a prospective PASS.

## Scientific meaning

GW250114 now supports these limited statements:

1. the public data and the finite-QNM inference implementation are compatible
   after the peak/reference state is correctly bound;
2. the source-informed 11M/R3A1 result is Kerr-consistent and calibration
   robust;
3. a pre-merger-only joint time/sky posterior can locate the detector peaks
   accurately enough for a future prospective application.

It does **not** show that the predicted 11M rule outperforms a traditional 5M
analysis for this event: the corrected 5M/R2A0 fit is also Kerr-consistent and
retains more SNR.  GW250114 is therefore a strong implementation diagnosis,
robustness result, and negative control—not a second decisive prospective
demonstration of the rule's advantage.

The current PRL case should continue to rest on the independent blind NR
validation, colored-noise false-deviation suppression, cross-extraction/mode
robustness, source/PSD/SNR uncertainty tests, and GW150914 prospective
demonstration.  GW250114 can be included as an honest feasibility and
failure-analysis section.

## Next decisive test

For an untouched event, before opening its ringdown:

1. reconstruct analytically marginalized time and phase;
2. map each joint low-frequency posterior sample to the full-IMR strain-norm
   peak;
3. prebind a joint-state or start-time-marginalized `(t_safe, N_opt)` rule;
4. open the ringdown and compare traditional, predicted, and conservative
   analyses under unchanged gates.

Success requires Kerr consistency and calibration robustness plus a
predeclared advantage: either reduced false-deviation risk or more retained
information than a conservative late start.  Without such an advantage, the
event should not be advertised as additional evidence for the rule.
