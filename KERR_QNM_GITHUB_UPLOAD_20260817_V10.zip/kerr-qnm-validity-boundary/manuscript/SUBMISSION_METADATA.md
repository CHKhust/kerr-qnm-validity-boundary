# Submission metadata

- Journal: Physical Review Letters
- Article type: Letter
- Title: Predicting the Validity Boundary of Finite Quasinormal Mode Spectroscopy
- Corresponding author: Pan-Pan Wang
- Email: ppwang@cqu.edu.cn
- ORCID: to be supplied by the authors if available
- PhySH concepts: black holes, gravitational waves, numerical relativity, general relativity, parameter estimation
- Previous APS submission history: none stated in the workspace
- Joint submission: no
- Suggested referees: to be supplied by the authors after conflict of interest review
- Excluded referees: none stated
- Open access choice: to be selected by the corresponding author in the APS portal
- Funding information: National Key R&D Program of China under Grant No. 2024YFC2207500 and National Natural Science Foundation of China under Grant No. 12405060
- Competing interests: The authors declare no conflicts of interest

## Files for peer review

1. `main.pdf`
2. `Supplemental_Material.pdf`
3. `cover_letter.pdf` or the text from `COVER_LETTER.md`
4. `PRL_100_WORD_JUSTIFICATION.txt`
5. `DATA_AVAILABILITY_STATEMENT.md`

The corresponding author must verify the ORCID, referee, publication option, and prior submission fields before the final portal submission.
