# SQVB manuscript bundle

This directory contains the final manuscript, Supplemental Material, cover letter, bibliography, figures, and compiled PDFs for the source-informed QNM validity boundary (SQVB). SNR is defined independently in the main text and Supplemental Material. The supplement is organized into boundary construction and validation, followed by detector and event analyses.
