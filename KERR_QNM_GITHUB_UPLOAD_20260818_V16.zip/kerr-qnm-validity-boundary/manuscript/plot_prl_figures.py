#!/usr/bin/env python3
"""Generate manuscript figures from existing authoritative result files."""

from __future__ import annotations

import json
import os
from pathlib import Path

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / ".mplconfig"))

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
FIGURE_DATA = HERE / "figure_data"
OUT = HERE / "figures"
OUT.mkdir(parents=True, exist_ok=True)


def load(filename: str):
    path = FIGURE_DATA / filename
    if not path.is_file():
        raise FileNotFoundError(f"missing bundled figure input: {path}")
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


mpl.rcParams.update(
    {
        "font.family": "Times New Roman",
        "font.serif": ["Times New Roman"],
        "mathtext.fontset": "custom",
        "mathtext.rm": "Times New Roman",
        "mathtext.it": "Times New Roman:italic",
        "mathtext.bf": "Times New Roman:bold",
        "font.size": 8.5,
        "axes.labelsize": 9,
        "axes.titlesize": 9,
        "legend.fontsize": 7.5,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "axes.linewidth": 0.75,
        "savefig.dpi": 300,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)

COLORS = {"blue": "#3366AA", "orange": "#EE7733", "green": "#228833", "gray": "#777777", "red": "#CC3311"}


def panel(ax, label, x=-0.14, y=1.05):
    ax.text(x, y, label, transform=ax.transAxes, fontweight="bold", va="top")
    ax.tick_params(direction="in", top=True, right=True)


def save(fig, stem):
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(OUT / f"{stem}.png", bbox_inches="tight")
    plt.close(fig)


def figure_mechanism():
    order = load("model_order_kerr_clock_result.json")["models"]
    clock = load("overtone_clearance_clock_result.json")
    ns = [2, 3, 4, 5]
    trepr = [order[f"N{n}"]["t_repr"]["median_M"] for n in ns]
    tspec = [order[f"N{n}"]["t_spec"]["median_M"] for n in ns]
    rows = [r for r in clock["rows"] if r["fitted_model"] == "N2"]
    observed = np.array([r["t_spec"] for r in rows])
    predicted = np.array(clock["by_fitted_model"]["N2"]["t_spec_clearance_fit"]["loocv_predictions_M"])

    fig, axes = plt.subplots(1, 2, figsize=(7.05, 2.75))
    ax = axes[0]
    ax.plot(ns, trepr, "o-", color=COLORS["blue"], label=r"Representability $t_{\rm repr}$")
    ax.plot(ns, tspec, "s-", color=COLORS["orange"], label=r"Spectroscopy $t_{\rm spec}$")
    ax.fill_between(ns, trepr, tspec, color=COLORS["gray"], alpha=0.13)
    ax.set(xlabel="Number of fitted QNMs", ylabel=r"Median boundary time  $(t-t_{\rm peak})/M$", xticks=ns)
    ax.legend(frameon=False)
    panel(ax, "(a)", x=-0.18, y=1.04)

    ax = axes[1]
    lo, hi = min(observed.min(), predicted.min()) - 1, max(observed.max(), predicted.max()) + 1
    ax.plot([lo, hi], [lo, hi], color=COLORS["gray"], lw=1, label="Exact prediction")
    ax.scatter(observed, predicted, s=24, facecolors="none", edgecolors=COLORS["blue"], linewidths=1)
    fit = clock["by_fitted_model"]["N2"]["t_spec_clearance_fit"]
    ax.text(0.05, 0.94, r"$\rho_{\rm LOO}=0.949$" + "\n" + rf"LOO MAE $={fit['loocv_mae_M']:.2f}M$", transform=ax.transAxes, va="top")
    ax.set(xlabel=r"Observed $t_{\rm spec}/M$", ylabel=r"Clearance prediction $t_{\rm spec}/M$", xlim=(lo, hi), ylim=(lo, hi))
    panel(ax, "(b)")
    fig.tight_layout()
    save(fig, "fig1_mechanism_model_order")


def figure_blind():
    data = load("scalar_vector_empirical_head_to_head_result.json")
    rows = data["per_system"]
    actual = np.array([r["actual_tsafe_M"] for r in rows])
    vector = np.array([r["vector_projected_tsafe_M"] for r in rows])
    scalar = np.array([r["scalar_last_component_tsafe_M"] for r in rows])
    empirical = np.array([r["direct_empirical_tsafe_M"] for r in rows])

    fig, axes = plt.subplots(1, 3, figsize=(7.05, 2.78))
    ax = axes[0]
    lo, hi = actual.min() - 1, actual.max() + 1
    ax.plot([lo, hi], [lo, hi], color=COLORS["gray"], lw=1)
    ax.scatter(actual, vector, s=18, color=COLORS["blue"], alpha=0.8)
    ax.set(xlabel=r"Observed $t_{\rm safe}/M$", ylabel=r"Predicted $t_{\rm safe}/M$", xlim=(lo, hi), ylim=(lo, hi))
    panel(ax, "(a)", x=0.02, y=0.98)

    ax = axes[1]
    values = [np.abs(vector - actual), np.abs(scalar - actual), np.abs(empirical - actual)]
    labels = ["Projected\nclearance", "Scalar\nclearance", "Direct\nempirical"]
    bp = ax.boxplot(values, tick_labels=labels, widths=0.6, showfliers=True, patch_artist=True)
    for patch, color in zip(bp["boxes"], [COLORS["blue"], COLORS["orange"], COLORS["green"]]):
        patch.set_facecolor(color)
        patch.set_alpha(0.35)
    ax.set_ylabel(r"Absolute error  $|\Delta t_{\rm safe}|/M$")
    panel(ax, "(b)", x=0.02, y=0.98)

    ax = axes[2]
    curve_handles = []
    curve_labels = []
    for arr, label, color, marker in [
        (vector, "Projected clearance", COLORS["blue"], "o"),
        (scalar, "Scalar clearance", COLORS["orange"], "s"),
        (empirical, "Direct empirical", COLORS["green"], "^"),
    ]:
        err = np.sort(np.abs(arr - actual))
        handle = ax.step(err, np.arange(1, len(err) + 1) / len(err), where="post", label=label, color=color)[0]
        curve_handles.append(handle)
        curve_labels.append(label)
    ax.axvline(2, color=COLORS["gray"], ls="--", lw=1)
    ax.set(xlabel=r"Absolute error  $|\Delta t_{\rm safe}|/M$", ylabel="Cumulative fraction", xlim=(0, 8), ylim=(0, 1.02))
    panel(ax, "(c)", x=0.02, y=0.98)
    fig.legend(curve_handles, curve_labels, frameon=False, loc="upper center", bbox_to_anchor=(0.73, 1.0), ncol=3, fontsize=7.0)
    fig.tight_layout(rect=(0, 0, 1, 0.90))
    save(fig, "fig2_blind_prediction")


def figure_false_kerr():
    data = load("scalar_vector_empirical_head_to_head_result.json")["downstream_colored_noise_h22"]
    masses = [70, 140]
    strategies = ["traditional", "proposed", "conservative30"]
    labels = ["Fixed early", "Predicted", "Conservative"]
    colors = [COLORS["orange"], COLORS["blue"], COLORS["gray"]]
    false = np.array([[data[str(m)][s]["false95_fraction"] for m in masses] for s in strategies])
    retained = np.array([[data[str(m)][s]["median_retained_snr_ratio"] for m in masses] for s in strategies])

    fig, axes = plt.subplots(1, 2, figsize=(7.05, 2.85))
    x = np.arange(len(masses))
    width = 0.24
    strategy_handles = []
    markers = ["s", "o", "^"]
    for i, (label, color, marker) in enumerate(zip(labels, colors, markers)):
        bar = axes[0].bar(x + (i - 1) * width, false[i], width, label=label, color=color, alpha=0.85)
        strategy_handles.append(bar[0])
        axes[1].plot(x, retained[i], marker=marker, lw=1.5, ms=5.5, color=color, label=label)
    ceiling = axes[0].axhline(0.15, color=COLORS["red"], ls="--", lw=1, label="Predefined ceiling")
    axes[0].set(ylabel="False Kerr exclusion fraction", xticks=x, xticklabels=[f"{m}" for m in masses], ylim=(0, 1.05))
    axes[0].set_xlabel("Detector frame total mass (solar masses)")
    panel(axes[0], "(a)", x=0.02, y=0.98)
    axes[1].set(ylabel="Median selected-window SNR ratio", xticks=x, xticklabels=[f"{m}" for m in masses], ylim=(0, 1.0))
    axes[1].set_xlabel("Detector frame total mass (solar masses)")
    panel(axes[1], "(b)", x=0.02, y=0.98)
    fig.legend([ceiling] + strategy_handles, ["Predefined ceiling"] + labels, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=4, fontsize=7.2)
    fig.tight_layout(rect=(0, 0, 1, 0.89))
    save(fig, "fig3_false_kerr_snr_tradeoff")


def figure_gw150914():
    push = load("gw150914_lalsuite_coherent_boundary_pushforward_result.json")
    real = load("gw150914_real_event_final_gate_result.json")
    bands = ["20_100Hz", "20_132Hz"]
    band_labels = ["20 to 100 Hz", "20 to 132 Hz"]
    med = [push["bands"][b]["h22"]["safe_t0_M"]["median"] for b in bands]
    q05 = [push["bands"][b]["h22"]["safe_t0_M"]["q05"] for b in bands]
    q95 = [push["bands"][b]["h22"]["safe_t0_M"]["q95"] for b in bands]
    strategies = ["traditional", "predicted", "conservative"]
    labels = ["Fixed early 5M", "Predicted 11M", "Conservative 15M"]
    nominal = real["nominal"]
    snr = [nominal[s]["optimal_network_snr_median"] for s in strategies]
    df = [nominal[s]["df220_median"] for s in strategies]
    dg = [nominal[s]["dg220_median"] for s in strategies]
    dferr = [nominal[s]["df220_std"] for s in strategies]
    dgerr = [nominal[s]["dg220_std"] for s in strategies]
    sky11 = load("v3_predicted_K64.json")["posterior"]
    sky15 = load("v3_conservative_K64.json")["posterior"]

    fig, axes = plt.subplots(1, 3, figsize=(7.05, 2.55))
    ax = axes[0]
    y = np.arange(2)
    ax.errorbar(med, y, xerr=[np.array(med) - np.array(q05), np.array(q95) - np.array(med)], fmt="o", color=COLORS["blue"], capsize=3)
    ax.set(xlabel=r"Prospective $t_{\rm safe}/M$", yticks=y, yticklabels=band_labels, xlim=(8, 14))
    ax.axvline(11, color=COLORS["gray"], lw=1, ls="--")
    panel(ax, "(a)", x=0.02, y=0.98)

    ax = axes[1]
    bars = ax.bar(np.arange(3), snr, color=[COLORS["orange"], COLORS["blue"], COLORS["gray"]], alpha=0.85)
    ax.set(ylabel="Reconstructed optimal network SNR", xticks=np.arange(3), xticklabels=["5M", "11M", "15M"], ylim=(0, 10))
    for i, (bar, val) in enumerate(zip(bars, snr)):
        if i > 0:
            ax.text(bar.get_x() + bar.get_width() / 2, val + 0.2, f"{val:.2f}", ha="center", va="bottom", fontsize=7)
    panel(ax, "(b)", x=0.02, y=0.98)

    ax = axes[2]
    legend_handles = []
    for i, (xv, yv, xe, ye, lab, col, marker) in enumerate(zip(df, dg, dferr, dgerr, labels, [COLORS["orange"], COLORS["blue"], COLORS["gray"]], ["s", "o", "^"])):
        artist = ax.errorbar(xv, yv, xerr=xe, yerr=ye, fmt=marker, color=col, capsize=2, label=lab)
        legend_handles.append(artist)
    common11 = ax.errorbar(
        sky11["df220_median"], sky11["dg220_median"],
        xerr=sky11["df220_std"], yerr=sky11["dg220_std"],
        fmt="D", color=COLORS["green"], capsize=2,
        label="11M common",
    )
    common15 = ax.errorbar(
        sky15["df220_median"], sky15["dg220_median"],
        xerr=sky15["df220_std"], yerr=sky15["dg220_std"],
        fmt="X", color=COLORS["green"], alpha=0.65, capsize=2,
        label="15M common",
    )
    ax.axhline(0, color=COLORS["gray"], lw=0.7)
    ax.axvline(0, color=COLORS["gray"], lw=0.7)
    kerr = ax.plot(0, 0, "+", color="black", ms=7, label="Kerr")[0]
    ax.set(xlabel=r"Log frequency ratio  $\delta f_{220}$", ylabel=r"Log damping-rate ratio  $\delta g_{220}$", xlim=(-0.22, 0.24), ylim=(-0.25, 0.26))
    panel(ax, "(c)", x=0.02, y=0.98)
    fig.legend([kerr] + legend_handles + [common11, common15], ["Kerr"] + labels + ["11M common", "15M common"], frameon=False, loc="upper center", bbox_to_anchor=(0.78, 1.01), ncol=3, fontsize=6.0, handlelength=1.2, labelspacing=0.25)
    fig.tight_layout(rect=(0, 0, 1, 0.84))
    save(fig, "fig4_gw150914_prospective")


def figure_gw250114_supplement():
    data = load("gw250114_root_cause_and_scientific_increment_v1.json")
    nominal = data["corrected_official_reference_diagnostic"]["nominal"]
    keys = ["traditional_5M_R2A0", "predicted_rule_R3A1", "conservative_15M_R3A1"]
    starts = [5, 11, 15]
    snr = [nominal[key]["optimal_network_snr_median"] for key in keys]
    fig, ax = plt.subplots(figsize=(3.45, 2.6))
    ax.plot(starts, snr, "o-", color=COLORS["blue"])
    ax.set(xlabel=r"Start time  $(t-t_{\rm peak})/M$", ylabel="Optimal network SNR", xticks=starts)
    fig.tight_layout()
    save(fig, "figS_gw250114_retrospective_diagnostic")


if __name__ == "__main__":
    figure_mechanism()
    figure_blind()
    figure_false_kerr()
    figure_gw150914()
    figure_gw250114_supplement()
