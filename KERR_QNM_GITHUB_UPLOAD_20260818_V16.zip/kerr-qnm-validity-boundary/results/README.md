# Result receipts

Use `claim_registry.json` as the machine-readable status authority. Upstream scientific statuses are retained in the individual sanitized result receipts; registry statuses express the public claim role without promoting failures, invalid runs, or post-hoc diagnostics.
