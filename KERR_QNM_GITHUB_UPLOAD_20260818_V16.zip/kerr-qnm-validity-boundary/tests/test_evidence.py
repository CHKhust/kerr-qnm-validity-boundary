from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load(relative: str):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def sha256(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        registry = load("results/claim_registry.json")
        self.registry = registry
        self.entries = {item["id"]: item for item in registry["entries"]}

    def test_headline_scope_is_bounded(self):
        self.assertEqual(self.registry["headline_scope"], "h22 finite-basis spectroscopy validity boundary")
        self.assertIs(self.registry["strong_real_event_no_hair_claim_ready"], False)
        self.assertIs(self.registry["mode_general_claim_ready"], False)

    def test_required_failure_lineage(self):
        expected = {
            "h33_cross_extraction": "PRESERVED_FAIL",
            "gw150914_joint_sky_v1": "INVALID",
            "gw150914_joint_sky_v2": "FAIL",
            "gw150914_joint_sky_v3_k64": "SUPPORTING",
            "gw250114_original_prospective_test": "INVALID",
            "h6_v3_terminal_sampler_failure": "TERMINAL_PROTOCOL_FAIL",
        }
        self.assertEqual({key: self.entries[key]["status"] for key in expected}, expected)
        self.assertEqual(self.entries["h33_cross_extraction"]["metrics"]["passed"], 42)
        self.assertEqual(self.entries["h33_cross_extraction"]["metrics"]["total"], 48)
        self.assertEqual(self.entries["gw150914_joint_sky_v3_k64"]["quadrature_nodes"], 64)
        self.assertIs(self.entries["gw150914_joint_sky_v3_k64"]["retrospective"], True)

    def test_remnant_sensitivities_are_not_new_blinds(self):
        for key in ("blind40_standard_remnant_sensitivity", "detector16_standard_remnant_sensitivity"):
            item = self.entries[key]
            self.assertEqual(item["status"], "POST_HOC_NONCOVERING")
            self.assertIs(item["new_blind_validation"], False)
            self.assertIs(item["principal_plot_input"], False)

    def test_claim_evidence_hashes(self):
        for item in self.entries.values():
            for record in item.get("evidence", []):
                self.assertTrue((ROOT / record["path"]).is_file())
                self.assertEqual(sha256(record["path"]), record["sha256"])

    def test_plot_data_is_exact_and_local(self):
        expected = {
            "model_order_kerr_clock_result.json",
            "overtone_clearance_clock_result.json",
            "scalar_vector_empirical_head_to_head_result.json",
            "gw150914_lalsuite_coherent_boundary_pushforward_result.json",
            "gw150914_real_event_final_gate_result.json",
            "v3_predicted_K64.json",
            "v3_conservative_K64.json",
            "gw250114_root_cause_and_scientific_increment_v1.json",
        }
        data = ROOT / "manuscript" / "figure_data"
        self.assertEqual({path.name for path in data.iterdir() if path.is_file()}, expected)
        source = (ROOT / "manuscript" / "plot_prl_figures.py").read_text(encoding="utf-8")
        self.assertIn('FIGURE_DATA = HERE / "figure_data"', source)
        self.assertNotIn("WORKSPACE", source)

    def test_external_manifest_is_compact(self):
        manifest = load("manifests/external_data.json")
        self.assertEqual(len(manifest["entries"]), 5)
        self.assertEqual(len(manifest["entries"][0]["logical_ids"]), 40)
        self.assertTrue(all(item["redistributed"] is False for item in manifest["entries"]))

    def test_text_audit_supersession_is_preserved(self):
        v6 = load("manuscript/audits/FINAL_TEXT_TERMINOLOGY_AUDIT_V6_PRESERVED_FAIL.json")
        v7 = load("manuscript/audits/FINAL_TEXT_TERMINOLOGY_AUDIT_V7.json")
        self.assertEqual(v6["status"], "FINAL_TEXT_TERMINOLOGY_AUDIT_V6_FAIL")
        self.assertEqual(v7["status"], "FINAL_TEXT_TERMINOLOGY_AUDIT_V7_PASS")
        self.assertEqual(v7["supersedes_due_to_auditor_bug"], "V6")


if __name__ == "__main__":
    unittest.main()
