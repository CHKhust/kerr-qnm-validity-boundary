# Results source of truth

This index maps each manuscript claim and figure to the authoritative result file. It excludes superseded results. The headline scope is the dominant (h_{22}) mode. The (h_{33}) analysis is a stated limitation because its cross extraction fraction did not reach the predefined requirement.

## Core physics

1. **Model order and clearance mechanism**
   - `../qnm_emergence_physics_synthesis_v1/model_order_kerr_clock_result.json`
   - `../qnm_emergence_physics_synthesis_v1/overtone_clearance_clock_result.json`
   - Figure: `figures/fig1_mechanism_model_order.pdf`

2. **Blind prediction on 40 numerical relativity waveforms**
   - `../qnm_prl_novelty_closure_v1/scalar_vector_empirical_head_to_head_result.json`
   - Post hoc standard-remnant sensitivity: `../qnm_blind40_standard_remnant_sensitivity_v1/blind40_standard_remnant_sensitivity_result.json`
   - Binding receipt: `../qnm_blind40_standard_remnant_sensitivity_v1/blind40_standard_remnant_sensitivity_receipt.json`
   - Primary N2 values at ringdown SNR 100: median absolute error (0M), 85 percent within (2M), and agreement with the oracle excitation risk selector in all 120 cases at 10M, 15M, and 20M. The corresponding agreement at 0M and 5M is 77.5 and 75.0 percent.
   - The registered blind test used catalog remnant mass and spin fixed before waveform opening. The post hoc standard-remnant replacement leaves all 40 N2 predictions and all 120 reported order selections unchanged. It is a sensitivity audit, not a new blind test.
   - Figure: `figures/fig2_blind_prediction.pdf`

3. **False Kerr exclusions and retained signal**
   - `../qnm_unified_blind_v2/unified_blind_colored_validation_v2_result.json`
   - Post hoc standard-remnant sensitivity: `../qnm_detector16_standard_remnant_sensitivity_v1/detector16_standard_remnant_sensitivity_result.json`
   - Binding receipt: `../qnm_detector16_standard_remnant_sensitivity_v1/detector16_standard_remnant_sensitivity_receipt.json`
   - Compact headline values are taken from `../qnm_prl_novelty_closure_v1/scalar_vector_empirical_head_to_head_result.json`.
   - Robustness sources:
     - `../qnm_detector_generalization_v1/psd_snr_generalization_result.json`
     - `../qnm_source_uncertainty_blind_v1/independent_source_uncertainty_blind_result.json`
     - `../qnm_h33_superrest_paired_v1/h22_radial_complete_cross_extraction_result.json`
   - Figure: `figures/fig3_false_kerr_snr_tradeoff.pdf`
   - Exact headline scope: Advanced LIGO design spectrum with peak-start reference SNR 200. The strategies are early $(5M,R2A0)$, proposed predicted start with a frozen $R3A1$ floor, and conservative $(30M,R2A0)$. The comparison changes both start time and basis.
   - Noise scope: paired seeded Gaussian draws in the whitened feature space, not cuts from one continuous detector strain realization.
   - Replacing catalog remnants with standard fits leaves all 32 target--mass start and basis decisions unchanged. This is a post hoc, noncovering sensitivity audit.

4. **Source-informed GW150914 application and retrospective common-support time-and-sky check**
   - Low-frequency source pushforward: `../qnm_prl_novelty_closure_v1/gw150914_lalsuite_coherent_boundary_pushforward_result.json`
   - Ringdown inference: `../qnm_prl_decisive_validation_v1/gw150914_real_event_final_gate_result.json`
   - Primary values: (t_{\rm safe}=11M), Kerr lies in the approximate KDE joint 95 percent highest density region, and the predicted start retains 14.9 percent more posterior reconstructed optimal SNR than the 15M reference. All 512 pre-floor inspiral evaluations propose R2A0. The detector analysis uses a predeclared R3A1 completeness floor.
   - Historical code review: `GW150914_CODE_REVIEW.md` and `GW150914_CODE_REVIEW.json` record the original no go before nonoverwriting repairs.
   - Publication scope closure: `GW150914_CODE_REVIEW_CLOSURE.md` records the repaired independence evidence and the remaining fixed sky limitation.
   - Independent seed repair: `../qnm_gw150914_independent_noise_repair_v1/independent_colored_noise_supplement_result.json`. It uses 30 distinct seeds per strategy at the median source and signal to noise ratio 25. The predicted result is 1/30 false exclusions, the conservative result is 0/30, and all convergence and retained information gates pass.
   - Post analysis independent noise extension: `../qnm_gw150914_independent_noise_span_v2/low_median_high_span_validation_result.json`. It passes with predicted false exclusions 0/10, 1/30, and 0/10 at low, median, and high source points.
   - Historical post analysis sky likelihood sensitivity: `../qnm_gw150914_sky_sensitivity_v1/sky_sensitivity_result.json`. It fails at three of five representative fixed skies and motivated the likelihood level calculation below.
   - Invalid historical implementation: `../qnm_gw150914_joint_sky_marginalization_v1/joint_sky_start_time_comparison.json`. It mixed likelihoods from different observed data segments and is excluded from scientific evidence.
   - Preserved strict failure: `../qnm_gw150914_joint_sky_marginalization_v2/common_sample_final_result.json`. The common sample implementation is mathematically valid, but its $K=16$ to $K=32$ check failed because one shift was 0.1004238 standard deviations against a strict value below 0.10.
   - Authoritative retrospective common support result: `../qnm_gw150914_joint_sky_marginalization_v3/v3_k64_extension_result.json`. Both $K=32$ to $K=64$ convergence checks pass. All four joint 95 percent regions contain Kerr. At $K=64$, the $11M$ and $15M$ frequency and damping medians differ by 0.0807 and 0.0573 pooled standard deviations.
   - Binding receipt: `../qnm_gw150914_joint_sky_marginalization_v3/COMMON_SAMPLE_K64_EXTENSION_RECEIPT_V2.json`. The same 82 detector samples and covariance matrices are used in every node and strategy. The check discards 19.61 percent of the original samples and is retrospective.
   - Mathematical sample space audit: `../qnm_gw150914_joint_sky_marginalization_v2/LIKELIHOOD_SAMPLE_SPACE_MATH_AUDIT.json`.
   - The factor 1.149 in retained reconstructed signal is from the recorded fixed sky comparison. The common support mixture does not generate marginalized amplitude draws and does not provide a time and sky marginalized signal to noise ratio.
   - Figure: `figures/fig4_gw150914_prospective.pdf`

## Required limits

- The boundary is a validity boundary for a finite QNM basis. It is not a time at which a Kerr black hole is born.
- The main conclusion is restricted to (h_{22}).
- `../qnm_prl_novelty_closure_v1/h33_no_retuning_stress_audit_result.json` records the (h_{33}) no go result.
- `../qnm_prl_decisive_validation_v1/h33_prospective_confirmation_result.json` is the direct source for 42/48, or 87.5 percent, and is a preserved failure below the 90 percent criterion.
- GW250114 is a retrospective timing diagnostic. It is not a second prospective confirmation.
- `../qnm_gw250114_prospective_v1/gw250114_root_cause_and_scientific_increment_v1.json` is its source.

## Figure generation

Run:

```powershell
& '..\qnm_gw150914_inspiral_pe_v1\.venv\Scripts\python.exe' '.\plot_prl_figures.py'
```

All generated PDF and PNG files are new manuscript artifacts. No scientific result file is modified.
