# Security and public-data policy

The V9 builder rejects bytecode caches, logs, raw numerical arrays, archives, virtual-machine images, key or environment files, private-key markers, symlinks, and machine-local absolute paths. Report a suspected credential or private-data disclosure to the corresponding author before public redistribution.
