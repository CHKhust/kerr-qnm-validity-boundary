from __future__ import annotations

import unittest

import numpy as np

from projected_omitted_risk import (
    aligo_zero_det_high_power_psd,
    flat_psd,
    projection_risk,
)


class ProjectedOmittedRiskTests(unittest.TestCase):
    def setUp(self) -> None:
        self.t = np.arange(0.0, 60.0, 0.05)
        self.target = complex(0.53260024, -0.08079287)
        self.overtone = complex(0.52116077, -0.24423832)
        self.quadratic = 2.0 * self.target
        self.included = ((self.target, 1.0j),)

    def risk(self, omitted, psd=flat_psd):
        return projection_risk(
            self.t,
            self.included,
            omitted,
            target_omega=self.target,
            target_coefficient=1.0j,
            dt_s=0.05 * 70.0 * 4.925490947e-6,
            rho=50.0,
            psd=psd,
        )

    def test_exact_phase_cancellation_is_preserved(self) -> None:
        canceled = self.risk(((self.overtone, 0.1j), (self.overtone, -0.1j)))
        self.assertLess(canceled["B"], 1.0e-10)
        self.assertGreater(canceled["scalar_omitted_norm_sum"], 0.0)
        self.assertLess(canceled["interference_ratio"], 1.0e-10)

    def test_constructive_interference_is_preserved(self) -> None:
        single = self.risk(((self.overtone, 0.1j),))
        doubled = self.risk(((self.overtone, 0.1j), (self.overtone, 0.1j)))
        self.assertGreater(doubled["B"], 1.8 * single["B"])

    def test_colored_psd_changes_projection(self) -> None:
        omitted = ((self.overtone, 0.1j), (self.quadratic, 0.05 + 0.05j))
        flat = self.risk(omitted, flat_psd)
        colored = self.risk(omitted, aligo_zero_det_high_power_psd)
        self.assertGreater(abs(flat["B"] - colored["B"]), 1.0e-3)

    def test_included_amplitude_direction_is_profiled_out(self) -> None:
        result = self.risk(((self.target, 0.2j),))
        self.assertLess(result["B"], 1.0e-8)


if __name__ == "__main__":
    unittest.main()
